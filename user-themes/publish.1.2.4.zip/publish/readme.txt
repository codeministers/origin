Publish is a clean minimal theme which puts you and your content on stage. Ideal for single-author blogs.

Version history:

1.2.4

* Fixed post formats appending to menus bug
* Added hidpi screenshot
* Support header images prior to 3.4
* Other minor bug fixes and enhancements

1.2.3

* A whole lot of changes from @obenland
* A lot of code cleanups, up to date with the latest _s
* Added support for custom headers (with fallback to Gravatar)

1.2.2

* No more hovercards on the logo
* Respect width/height attributes for images in the content area

1.2.1

* Better wp_title usage
* Fixed undefined notice and minor action vs filter issue

1.2

* Added support for Jetpack's infinite scroll
* Footer credits via an action
* Minor h2/h3 bump
* Undefined notice fix

1.1

* Total revamp, with underscores
* Version in @since blocks remained 1.0

1.0

* Back when Publish was not yet Publish but some random theme used on a random blog
* There weren't any version numbers, only commits
