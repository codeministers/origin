<div id="footer">
	<p class="floatleft">&copy; 2009 All rights reserved - <a href="<?php bloginfo('url'); ?>" title="<?php bloginfo('name'); ?>"><strong><?php bloginfo('name'); ?></strong></a> is powered by <a href="http://www.wordpress.org" title="WordPress">WordPress</a></p>
	<p class="floatright"><a href="http://www.artmov.com/blog/246/neutra-theme-for-wordpress/" title="Neutra by Artmov" rel="nofollow">Neutra</a></p>
	<?php wp_footer(); ?>
<div class="clearing"></div>
</div><!-- end #footer -->
</div><!-- end #container -->
</body>
</html>