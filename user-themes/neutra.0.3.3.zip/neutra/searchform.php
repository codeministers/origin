<form method="get" id="searchform" action="<?php bloginfo('home'); ?>/">
<input type="text" size="12" value="search this blog" name="s" id="s" class="ipt-keywords" onfocus="if(this.value == this.defaultValue) this.value = ''"/>
</form>