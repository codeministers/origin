<div id="footer">
	<?php wp_footer(); ?>	
		<!-- <?php echo get_num_queries(); ?> queries. <?php timer_stop(1); ?> seconds. -->
</div><!-- end footer -->
</div><!-- end wrapper -->
</body>
</html>