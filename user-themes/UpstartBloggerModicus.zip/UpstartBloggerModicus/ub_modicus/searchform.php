<div id="applesearch">
<form method="get" id="search_form" action="<?php bloginfo('home'); ?>/">				
		<span class="sbox_l"></span><span class="sbox"><input type="search" name="s" id="s" placeholder="Search..." autosave="applestyle_srch" results="5" onkeyup="applesearch.onChange('srch_fld','srch_clear')" /></span><span class="sbox_r" id="srch_clear"></span>
			<input type="hidden" id="searchsubmit" value="Search" />
</form>	</div>