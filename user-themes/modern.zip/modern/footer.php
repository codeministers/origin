<hr />
<div id="footer">
	<p>
		<?php bloginfo('name'); ?> uses <a href="http://ulfpettersson.se/design/modern/">Modern</a> &#8212; designed by <a href="http://ulfpettersson.se/">Ulf Pettersson</a> and powered by
		<a href="http://wordpress.org">WordPress</a>
		<br /><a href="feed:<?php bloginfo('rss2_url'); ?>">Entries (RSS)</a>
		and <a href="feed:<?php bloginfo('comments_rss2_url'); ?>">Comments (RSS)</a>.
	</p>
</div>
</div>

<!-- Wonderful design by Ulf Pettersson - http://ulfpettersson.se/ -->

		<?php wp_footer(); ?>

</body>
</html>