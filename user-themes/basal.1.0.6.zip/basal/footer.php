<div id="copy"><p>
Copyright &copy; <!-- Insert Your Name --> 
<?php echo date("Y")?>, |
<?php bloginfo('name'); ?> is proudly powered by
		<a href="http://wordpress.org/">WordPress</a>


<span class="thin">All rights Reserved</span> | Theme by <a href="http://ryanmcnair.co.uk/">Ryan McNair</a></p>
	<p><?php wp_footer() ?></p>
</div>
</div>
</body>

<!-- Can put web stats code here -->

</html> 