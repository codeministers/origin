<?php get_header(); ?>
<?php get_sidebar(); ?>

		<h1>Not Found</h1>
		<p>Sorry, but you are looking for something that isn't here.</p>
		<?php include (TEMPLATEPATH . "/searchform.php"); ?>

          
<?php get_footer(); ?>