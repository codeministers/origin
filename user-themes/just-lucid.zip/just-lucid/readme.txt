Theme name: Just Lucid
Theme author: Theme Lab
Author URL: http://www.themelab.com

Original template design by DemusDesign.com.

use of this theme requires compliance with the terms of service located at http://www.themelab.com/terms-of-service/

Under no circumstances shall the footer branding links be removed without prior consent of Theme Lab.